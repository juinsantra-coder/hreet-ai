# HREET AI Orange Nexus v1.1.0 — Google permissions + phone pairing

This package upgrades the v1.0 prototype with a real local PC companion server, a phone pairing page, and a Google OAuth/Gmail permission interface.

## 1. Start HREET on Windows

1. Install Python 3.10 or newer from <https://www.python.org/downloads/>. During setup, select **Add python.exe to PATH**.
2. Extract the complete ZIP to a normal folder, e.g. `C:\HREET_AI`.
3. Double-click `START_HREET_AI.bat`. The PC dashboard should open at `http://localhost:8765/`.
4. Keep the black console window running while you use pairing. On first start, Windows Firewall may ask about Python: permit **Private networks only** if you want to pair over your home Wi-Fi. Do not permit this on public networks.

The server uses only Python's standard library; it does not need `pip install` dependencies.

## 2. Configure Google sign-in and Gmail scopes

The package cannot sign in to Google until you create/configure your own OAuth client. This is intentional: HREET must not collect your Google password or an OTP.

1. Open <https://console.cloud.google.com/> and create/select a project.
2. In **Google Auth Platform**, configure the app branding and consent screen. For personal testing, use the Testing audience and add your own Google account as a test user if required.
3. In **Clients**, create an OAuth Client ID of type **Web application**.
4. Add this exact **Authorized JavaScript origin**: `http://localhost:8765`
5. Enable the **Gmail API** in that Google Cloud project if you intend to use Gmail permissions.
6. Copy the OAuth Client ID (ending in `.apps.googleusercontent.com`) into HREET → **Google & Pairing Setup**.
7. Select only permissions you need, then press **Sign in & ask Google permissions**. Google will show its own account-selection/consent UI.

Scopes:
- Basic Google identity: `openid email profile` (always requested for account identification).
- Optional Gmail read: `https://www.googleapis.com/auth/gmail.readonly` (allows HREET to display up to five recent email headers).
- Optional Gmail send: `https://www.googleapis.com/auth/gmail.send` (allows the compose panel to send a real email; the UI asks for confirmation immediately before sending).

If Gmail permissions are declined, expire, or are not granted, related features remain unavailable. For public distribution, Google may require verification for sensitive Gmail scopes. Read Google's current requirements at:
- <https://developers.google.com/identity/oauth2/web/guides/overview>
- <https://developers.google.com/workspace/gmail/api/auth/scopes>
- <https://developers.google.com/identity/protocols/oauth2/policies>

**Token handling:** Google access tokens are held only in JavaScript memory, not in local storage and not sent to the HREET pairing server. Reloading the page clears the active OAuth session, so sign in again before starting a pairing session. The public Client ID is saved in this browser's local storage; do not put any client secret or API key in this field.

## 3. Pair your phone with the PC

1. On the PC, use HREET → **Google & Pairing Setup** and connect your Google account in the current browser session.
2. Press **Generate one-time code**. The code expires after 3 minutes and can be used once.
3. Keep the phone and PC on the same trusted private Wi-Fi network.
4. On the phone, open the pairing URL printed in the PC app, generally like `http://192.168.x.x:8765/pair`.
5. Enter the one-time code, give the device a name, choose any optional capability requests, and submit. You must affirm the consent statement.
6. Check the request shown on the PC. Verify the device name/capability requests and press **Approve phone** or **Deny request**.
7. When approved, the phone gets a random session token, sends heartbeat messages, and appears in the PC's paired-device list. Use **Revoke** to remove a device.

If the phone cannot load the pairing URL, confirm both devices are on the same Wi-Fi, check the LAN IP printed in the server console, and allow Python through Windows Firewall for **Private networks** only.

## What really works vs. what is not implemented

Implemented:
- Google Identity Services OAuth consent using the Client ID you configure.
- Optional Gmail API read preview and send-email panel (scope-gated; sending requires a final confirmation).
- Local one-time pairing code, 3-minute expiry, one-time claim, phone consent, PC approval/denial, random pairing token, token-hash storage in process memory, heartbeat, device list and revoke.
- The PC management endpoints refuse requests that do not originate from loopback; browser API calls are same-origin checked.

Not yet implemented:
- Cross-device voice/audio relay, file transfer, app launching, arbitrary PC control, push notifications, or a general remote command channel. Device pairing alone does not activate any of these features.
- Encrypted HTTPS for phone-to-PC LAN traffic. This is a **local development service**, using HTTP on a trusted private Wi-Fi network only; a token could be observed by another party able to intercept local traffic. Never use it over public Wi-Fi or expose/port-forward port 8765 to the internet.
- Persistent paired-device storage. The local server keeps pair sessions in memory; stopping/restarting the server clears them and requires pairing again.

Do not treat a successful pair handshake as granting operating-system access. Each future capability needs its own implementation, platform permission prompt, and explicit confirmation. Review the code before trusting it with sensitive work.
