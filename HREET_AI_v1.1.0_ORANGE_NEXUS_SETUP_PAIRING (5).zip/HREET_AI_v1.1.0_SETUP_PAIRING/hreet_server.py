#!/usr/bin/env python3
"""HREET AI Orange Nexus local development server and one-time phone pairing broker.

Security boundary: PC-only management endpoints are restricted to loopback clients.
Phone endpoints allow only same-origin requests on this server. Pairing tokens are
random and single-use during handoff; token hashes are held only in process memory.
This is a LAN development companion, not a production Internet server.
"""
from __future__ import annotations
import hashlib, ipaddress, json, os, secrets, socket, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get('HREET_PORT', '8765'))
CODE_ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'
LOCK = threading.RLock()
SESSIONS: dict[str, dict] = {}
DEVICES: dict[str, dict] = {}
ACTIVE_CODES: dict[str, str] = {}
ATTEMPTS: dict[str, list[float]] = {}
CODE_TTL = 180


def digest(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(('8.8.8.8', 80))
        ip = sock.getsockname()[0]
        return ip if not ip.startswith('127.') else ''
    except OSError:
        return ''
    finally:
        sock.close()

LAN_IP = local_ip()


def now() -> float:
    return time.time()


def clean_expired() -> None:
    current = now()
    for sid, sess in list(SESSIONS.items()):
        if sess['expires_at'] < current and (not sess.get('request') or sess['request'].get('status') != 'paired'):
            ACTIVE_CODES.pop(sess.get('code_hash', ''), None)
            req = sess.get('request')
            if req and req.get('status') == 'pending_approval':
                req['status'] = 'expired'
            if sess['expires_at'] < current - 600:
                SESSIONS.pop(sid, None)
    for ip, stamps in list(ATTEMPTS.items()):
        ATTEMPTS[ip] = [t for t in stamps if current - t < 60]
        if not ATTEMPTS[ip]:
            ATTEMPTS.pop(ip, None)


class HreetHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    server_version = 'HREETLocal/1.1'

    def log_message(self, format, *args):
        # Don't log query strings, pairing codes, IDs, tokens, or Gmail details.
        print(f'[{self.log_date_time_string()}] {self.client_address[0]} {self.command} {self.path.split("?", 1)[0]}')

    def _headers(self, content_type='application/json; charset=utf-8', status=200):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin-allow-popups')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Frame-Options', 'DENY')
        self.end_headers()

    def _json(self, value, status=200):
        payload = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self._headers(status=status)
        self.wfile.write(payload)

    def _file(self, path: Path, content_type: str):
        try:
            payload = path.read_bytes()
        except OSError:
            self._json({'error': 'File not found'}, 404)
            return
        self._headers(content_type)
        self.wfile.write(payload)

    def _is_loopback(self) -> bool:
        try:
            return ipaddress.ip_address(self.client_address[0]).is_loopback
        except ValueError:
            return False

    def _same_origin(self) -> bool:
        origin = self.headers.get('Origin')
        host = self.headers.get('Host', '')
        if not origin:
            # Browser fetch normally includes Origin for JSON POST. Require it for CSRF-sensitive API.
            return False
        parsed = urlparse(origin)
        return parsed.scheme == 'http' and parsed.netloc.lower() == host.lower()

    def _body(self) -> dict:
        length = int(self.headers.get('Content-Length', '0'))
        if length < 1 or length > 32768:
            raise ValueError('Request body must be between 1 and 32768 bytes.')
        raw = self.rfile.read(length)
        value = json.loads(raw.decode('utf-8'))
        if not isinstance(value, dict):
            raise ValueError('JSON body must be an object.')
        return value

    def do_GET(self):
        path = urlparse(self.path).path
        qs = parse_qs(urlparse(self.path).query)
        if path in ('/', '/index.html'):
            return self._file(BASE / 'index.html', 'text/html; charset=utf-8')
        if path == '/pair':
            return self._file(BASE / 'pair.html', 'text/html; charset=utf-8')
        if path == '/api/info':
            phone_url = f'http://{LAN_IP}:{PORT}/pair' if LAN_IP else ''
            return self._json({'ok': True, 'port': PORT, 'lan_ip': LAN_IP, 'phone_url': phone_url,
                               'mode': 'local-lan-pairing', 'transport': 'HTTP development only',
                               'capabilities': ['one-time pairing handshake', 'device heartbeat', 'revoke']})
        if path == '/api/pair/status':
            if not self._is_loopback():
                return self._json({'error': 'PC pairing management is available only from this PC.'}, 403)
            sid = (qs.get('session_id') or [''])[0]
            with LOCK:
                clean_expired()
                sess = SESSIONS.get(sid)
                if not sess:
                    return self._json({'error': 'Pairing session not found or expired.'}, 404)
                req = sess.get('request')
                public_req = None
                if req:
                    public_req = {k: req.get(k) for k in ('request_id', 'device_name', 'scopes', 'status', 'created_at')}
                self._json({'ok': True, 'request': public_req, 'expired': sess['expires_at'] < now()})
            return
        if path == '/api/pair/phone-status':
            rid = (qs.get('request_id') or [''])[0]
            with LOCK:
                clean_expired()
                for sess in SESSIONS.values():
                    req = sess.get('request')
                    if req and secrets.compare_digest(req.get('request_id', ''), rid):
                        result = {'ok': True, 'status': req['status'], 'device_name': req['device_name']}
                        if req['status'] == 'paired' and req.get('token_once') and not req.get('token_delivered'):
                            result.update({'token': req['token_once'], 'device_id': req['device_id']})
                            req['token_delivered'] = True
                            req['token_once'] = ''
                        self._json(result)
                        return
            return self._json({'error': 'Pairing request not found or expired.'}, 404)
        if path == '/api/pair/devices':
            if not self._is_loopback():
                return self._json({'error': 'Device management is available only from this PC.'}, 403)
            with LOCK:
                items = [{'device_id': d['device_id'], 'name': d['name'], 'scopes': d['scopes'], 'created_at': d['created_at'], 'last_seen': d.get('last_seen', 0)} for d in DEVICES.values()]
            return self._json({'ok': True, 'devices': items})
        return self._json({'error': 'Not found'}, 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if not self._same_origin():
            return self._json({'error': 'Request origin validation failed. Open HREET via its local URL.'}, 403)
        try:
            body = self._body()
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            return self._json({'error': str(exc)}, 400)
        if path in ('/api/pair/start', '/api/pair/approve', '/api/pair/deny', '/api/pair/unpair') and not self._is_loopback():
            return self._json({'error': 'This pairing management action can only be done from the PC itself.'}, 403)
        if path == '/api/pair/start':
            with LOCK:
                clean_expired()
                code = ''.join(secrets.choice(CODE_ALPHABET) for _ in range(8))
                sid = secrets.token_urlsafe(32)
                expires = now() + CODE_TTL
                code_hash = digest(code)
                SESSIONS[sid] = {'session_id': sid, 'code_hash': code_hash, 'expires_at': expires, 'created_at': now(), 'request': None}
                ACTIVE_CODES[code_hash] = sid
                return self._json({'ok': True, 'session_id': sid, 'code': code, 'expires_at': expires,
                                   'phone_url': f'http://{LAN_IP}:{PORT}/pair' if LAN_IP else f'http://<PC-LAN-IP>:{PORT}/pair',
                                   'expires_in': CODE_TTL})
        if path == '/api/pair/claim':
            ip = self.client_address[0]
            with LOCK:
                clean_expired()
                stamps = ATTEMPTS.setdefault(ip, [])
                stamps[:] = [t for t in stamps if now() - t < 60]
                if len(stamps) >= 10:
                    return self._json({'error': 'Too many code attempts. Wait one minute and try again.'}, 429)
                stamps.append(now())
                code = str(body.get('code', '')).strip().upper()
                name = str(body.get('device_name', '')).strip()[:40]
                scopes = body.get('scopes', [])
                consent = body.get('consent') is True
                valid_scopes = {'voice_requested', 'selected_file_transfer', 'pc_action_approval'}
                if len(code) != 8 or any(ch not in CODE_ALPHABET for ch in code):
                    return self._json({'error': 'Enter the 8-character code shown on the PC.'}, 400)
                if not name:
                    return self._json({'error': 'Device name is required.'}, 400)
                if not consent:
                    return self._json({'error': 'You must confirm the pairing consent statement.'}, 400)
                if not isinstance(scopes, list) or any(x not in valid_scopes for x in scopes):
                    return self._json({'error': 'Invalid capability request.'}, 400)
                code_hash = digest(code)
                sid = ACTIVE_CODES.get(code_hash)
                sess = SESSIONS.get(sid or '')
                if not sess or sess['expires_at'] < now() or sess.get('request') is not None:
                    return self._json({'error': 'Code is wrong, expired or already used. Generate a new code on the PC.'}, 400)
                ACTIVE_CODES.pop(code_hash, None)  # one time, immediately
                rid = secrets.token_urlsafe(32)
                sess['request'] = {'request_id': rid, 'device_name': name, 'scopes': scopes, 'status': 'pending_approval', 'created_at': now(), 'token_once': '', 'token_delivered': False, 'device_id': ''}
                return self._json({'ok': True, 'request_id': rid, 'status': 'pending_approval'})
        if path in ('/api/pair/approve', '/api/pair/deny'):
            sid = str(body.get('session_id', ''))
            rid = str(body.get('request_id', ''))
            with LOCK:
                sess = SESSIONS.get(sid)
                req = sess.get('request') if sess else None
                if not req or not secrets.compare_digest(req.get('request_id', ''), rid):
                    return self._json({'error': 'Pairing request not found.'}, 404)
                if sess['expires_at'] < now() or req['status'] != 'pending_approval':
                    req['status'] = 'expired' if sess['expires_at'] < now() else req['status']
                    return self._json({'error': 'Pairing request is no longer pending.'}, 409)
                if path.endswith('/deny'):
                    req['status'] = 'denied'
                    return self._json({'ok': True, 'status': 'denied', 'device_name': req['device_name']})
                token = secrets.token_urlsafe(48)
                device_id = secrets.token_hex(6)
                DEVICES[device_id] = {'device_id': device_id, 'token_hash': digest(token), 'name': req['device_name'], 'scopes': list(req['scopes']), 'created_at': now(), 'last_seen': 0}
                req['status'] = 'paired'
                req['device_id'] = device_id
                req['token_once'] = token
                req['approved_at'] = now()
                return self._json({'ok': True, 'status': 'paired', 'device_name': req['device_name'], 'device_id': device_id})
        if path == '/api/pair/heartbeat':
            token = str(body.get('token', ''))
            if not token or len(token) > 256:
                return self._json({'error': 'Missing or invalid pairing token.'}, 401)
            th = digest(token)
            with LOCK:
                match = next((d for d in DEVICES.values() if secrets.compare_digest(d['token_hash'], th)), None)
                if not match:
                    return self._json({'error': 'Device session invalid or revoked. Pair again.'}, 401)
                match['last_seen'] = now()
                return self._json({'ok': True, 'device_id': match['device_id'], 'device_name': match['name'], 'scopes': match['scopes'], 'last_seen': match['last_seen']})
        if path == '/api/pair/unpair':
            device_id = str(body.get('device_id', ''))
            with LOCK:
                if device_id not in DEVICES:
                    return self._json({'error': 'Device not found.'}, 404)
                DEVICES.pop(device_id, None)
            return self._json({'ok': True, 'revoked': True})
        return self._json({'error': 'Not found'}, 404)


def main():
    if not (BASE / 'index.html').exists() or not (BASE / 'pair.html').exists():
        raise SystemExit('index.html and pair.html must be next to hreet_server.py')
    server = HreetHTTPServer(('0.0.0.0', PORT), Handler)
    print('\nHREET AI Orange Nexus — local companion')
    print(f'PC dashboard: http://localhost:{PORT}/')
    if LAN_IP:
        print(f'Phone pairing page (same private Wi-Fi): http://{LAN_IP}:{PORT}/pair')
    else:
        print(f'Phone pairing page: <PC-LAN-IP>:{PORT}/pair (run ipconfig if LAN IP is unknown)')
    print('Pairing code is one-time and expires in 3 minutes.')
    print('NOTICE: HTTP development service only. Private Wi-Fi only; never port-forward to the Internet.')
    print('Press Ctrl+C to stop. Pairings are memory-only and reset when the server stops.\n')
    threading.Timer(0.8, lambda: webbrowser.open(f'http://localhost:{PORT}/')).start()
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        print('\nStopping HREET local companion…')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
