@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer was not found.
  echo Install Python from https://www.python.org/downloads/ and select "Add python.exe to PATH".
  pause
  exit /b 1
)
python hreet_server.py
pause
